CREATE FUNCTION `showAllAd`(`where1` VARCHAR(7))
  RETURNS VARCHAR(1000)
BEGIN
  DECLARE out_name VARCHAR(1000);
  SELECT group_concat(ad.path) FROM ad WHERE `where`= where1 GROUP BY `where` INTO out_name;
  RETURN out_name;
END